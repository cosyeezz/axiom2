# 9600d738-2b59-4f4a-ad87-27efd8d6ad11 implementation handoff

This archive is the source of truth for turning the design into production code. Start from `coding-agent-v2-before-subagent-modal-v2.html`, then preserve the visual system, responsive behavior, and interactions found in the exported files.

## Implementation target
- Build production UI from the exported design, not a loose reinterpretation.
- Preserve typography scale, spacing rhythm, color tokens, border radii, shadows, motion timing, and component states.
- Replace static placeholders only when the target app has real data or functional equivalents.
- Keep generated product UI free of OpenDesign chrome, preview labels, or design-process annotations.
- Treat this handoff as a visual contract: if implementation choices conflict, match the exported pixels and behavior first, then refactor internals.

## Source map
- Primary entry: `coding-agent-v2-before-subagent-modal-v2.html`
- HTML screens detected: 14
- Stylesheets detected: 0
- Script/component files detected: 13
- Supporting assets detected: 44

## Responsive contract
Validate the implementation across this 2025–2026 viewport matrix:
- Mobile compact: 360×800
- Mobile standard: 390×844
- Mobile large: 430×932
- Foldable / small tablet: 600×960
- Tablet portrait: 820×1180
- Tablet landscape: 1024×768
- Laptop: 1366×768
- Desktop: 1440×900
- Wide desktop: 1920×1080

For responsive web exports, treat these as a modern breakpoint system for one adaptive web experience, not three fixed screenshots. Do not split responsive web into unrelated native app screens unless the project explicitly includes native targets. Use semantic layout thresholds, fluid `clamp()` type/spacing, and container queries where component width matters more than viewport width. Preserve any CSS media queries, container queries, fluid `clamp()` scales, and layout changes already present in the exported files.

## Design fidelity contract
- Extract reusable tokens before writing components: background, surface, foreground, muted text, border, accent, radius, shadow, spacing, type scale, and motion duration/easing.
- Map product screens, in-app modules/components, optional landing page, and optional OS widget surfaces before coding. Keep these surfaces separate in the target architecture.
- Match layout geometry: max-widths, gutters, grid columns, card proportions, sticky/fixed elements, and viewport-specific navigation.
- Preserve real copy, labels, and data shown in the export. Do not replace specific text with generic marketing filler.
- Preserve interactive affordances: hover, focus, pressed, disabled, loading, validation, copy/share, tab/accordion, modal/sheet, and keyboard states where present.
- Preserve accessibility semantics when converting: headings stay hierarchical, controls remain buttons/links/inputs, focus states stay visible.
- Do not keep prototype-only annotations, frame labels, or OpenDesign chrome in the production UI.

## CJX-ready UX contract
- Use `DESIGN-MANIFEST.json` as the machine-readable map for screens, app modules, OS widgets, landing pages, tokens, interactions, and viewport checks.
- Screen-file-first: when multiple user-facing surfaces exist, implement each HTML screen as its own route/file. Treat `index.html` as a launcher/overview when the manifest marks it that way, not as a combined final UI.
- If `landing.html`, app screens, platform screens, or OS widget files exist, preserve those boundaries in the target app instead of merging them into one page.
- A single self-contained `coding-agent-v2-before-subagent-modal-v2.html` is acceptable only when the export truly contains one user-facing screen and its CSS/JS are structured enough to extract tokens, components, states, and behavior.
- If separate `css/` or `js/` files exist, treat them as source of truth for token/component/interactions before porting to React, Vue, SwiftUI, Compose, or another target stack.
- In-app modules/components are product UI blocks inside the app. OS widgets are home-screen/lock-screen/quick-access surfaces outside the app. Do not merge those concepts.

## Color and brand contract
- Use the exported design tokens and product/domain context as the color source of truth.
- Do not introduce warm beige / cream / peach / pink / orange-brown background washes unless they are already explicit brand/reference colors in the export.
- No obvious token stylesheet was detected; sample colors from the entry file and convert them into named tokens before coding.

## Implementation sequence for AI coding tools
1. Open `coding-agent-v2-before-subagent-modal-v2.html` and `DESIGN-MANIFEST.json`; identify every screen file, launcher/overview file, app module, and interaction before coding.
2. If multiple HTML screens exist, map them to separate routes/surfaces first; do not merge `landing.html`, product app screens, platform screens, or OS widgets into one route.
3. Extract a token table from CSS/root styles and inline styles before building framework components.
4. Build product screens and domain-specific in-app modules from largest layout regions down to controls; avoid starting with isolated atoms that lose spatial intent.
5. Port responsive behavior across the modern viewport matrix and test each semantic breakpoint before cleanup.
6. Port interactions and states, then replace static placeholders only with real app data or functional equivalents.
7. Keep optional landing page and OS widget surfaces as separate surfaces if present.
8. Compare final screenshots against the export at 360×800, 390×844, 430×932, 820×1180, 1024×768, 1366×768, 1440×900, and 1920×1080 before declaring done.

## Entry points
- `coding-agent-v2-before-subagent-modal-v2.html`
- `coding-agent-v2.html`
- `coding-agent.html`
- `model-config-before-compact-ui-v2.html`
- `model-config-before-inline-create-v2.html`
- `model-config-before-layout-fix-v2.html`
- `model-config-before-provider-flow-v2.html`
- `model-config-before-provider-tabs-v2.html`
- `model-config-before-single-page-v2.html`
- `model-config-before-tabs-v2.html`
- `model-config-before-unified-save-v2.html`
- `model-config-v2.html`
- `model-config.html`
- `settings.html`

## Styles
- None detected

## Scripts/components
- `coding-agent-running.check.cjs`
- `coding-agent.check.cjs`
- `context-gauge.check.cjs`
- `conversation-markdown.check.cjs`
- `duration-usage.check.cjs`
- `estimated-cost.check.cjs`
- `model-config.check.cjs`
- `model-picker.check.cjs`
- `reasoning-levels.check.cjs`
- `session-initialization.check.cjs`
- `session-status-examples.check.cjs`
- `subagent-conversation.check.cjs`
- `workspace-selection.check.cjs`

## Assets and supporting files
- `coding-agent-preview.png`
- `image-1.png`
- `image-10.png`
- `image-11.png`
- `image-12.png`
- `image-13.png`
- `image-14.png`
- `image-15.png`
- `image-16.png`
- `image-17.png`
- `image-18.png`
- `image-19.png`
- `image-2.png`
- `image-3.png`
- `image-4.png`
- `image-5.png`
- `image-6.png`
- `image-7.png`
- `image-8.png`
- `image-9.png`
- `image.png`
- `PixPin_2026-10-11_01-31-18.png`
- `PixPin_2026-10-11_01-34-11.png`
- `PixPin_2026-10-11_03-03-05.png`
- `PixPin_2026-10-11_03-03-29.png`
- `PixPin_2026-10-11_03-07-43.png`
- `PixPin_2026-10-11_03-11-11.png`
- `PixPin_2026-10-11_03-13-43.png`
- `PixPin_2026-10-11_07-02-22.png`
- `PixPin_2026-10-11_07-05-47.png`
- `PixPin_2026-10-11_07-10-39.png`
- `PixPin_2026-10-11_07-23-50.png`
- `PixPin_2026-10-11_07-42-04-1.png`
- `PixPin_2026-10-11_07-42-04.png`
- `PixPin_2026-10-11_07-42-42.png`
- `PixPin_2026-10-11_07-55-31.png`
- `PixPin_2026-10-11_08-08-54.png`
- `PixPin_2026-10-11_08-18-11.png`
- `PixPin_2026-10-11_08-51-22.png`
- `PixPin_2026-10-11_09-05-52.png`
- `PixPin_2026-10-11_09-06-17.png`
- `PixPin_2026-10-11_19-57-23.png`
- `PixPin_2026-10-11_23-16-00.png`
- `screenshot-2026-10-12T09-41-31-049Z.png`

## Coding checklist for AI tools
1. Inspect `coding-agent-v2-before-subagent-modal-v2.html` and `DESIGN-MANIFEST.json` first and identify reusable components before coding.
2. Implement each user-facing screen file as its own route/surface; keep launcher, landing, app, platform, and OS widget files separate.
3. Extract design tokens into the target stack: colors, type scale, spacing, radius, shadows, and motion.
4. Implement layout with real 2025–2026 responsive breakpoints, fluid type/spacing, and container-query-aware component behavior; test with no horizontal overflow.
5. Preserve interactive controls, hover/focus/pressed states, form behavior, validation, and copy actions where present.
6. Implement domain-specific in-app modules with real states; do not flatten them into generic cards.
7. Keep landing page, product screens, and OS widget/quick-access surfaces separate when present.
8. Confirm the production result visually matches the exported design before refactoring internals.
9. Reject implementation shortcuts that flatten the design into generic cards, generic gradients, placeholder stats, or framework-default typography.
10. If a detail is ambiguous, keep the exported HTML/CSS/JS behavior rather than inventing a new pattern.
